This project contains the aaltoseries class file and docs.

The zip file 'examples.zip' contains a number of example files. In order to
compile them, copy aaltoseries.cls from root into this directory, and also
obtain a copy of aaltologo.sty and place it there.

