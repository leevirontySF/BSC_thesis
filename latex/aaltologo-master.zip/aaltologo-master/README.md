This is the home of the file aaltologo.sty, which generates the Aalto logo's for documents and also otherwise defines relevant parts of the Aalto visual identity,
specifically, colours and fonts used, and the official names of Schools, Institutes, etc. as used in the various logos, in Finnish, English and Swedish.
